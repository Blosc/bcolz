Airspeed velocity
=================
For more information how to run it please visit
http://asv.readthedocs.org/en/latest/using.html
Some examples:
`asv run`
`asv run --skip-existing-commits -s 10 ALL`

Preview results
---------------
```
asv publish
asv preview
firefox  http://127.0.0.1:8080/
```

Upload results to github pages
------------------------------
```
asv gh-pages
visit http://<your_githhub_username>.github.io/bcolz/
```
