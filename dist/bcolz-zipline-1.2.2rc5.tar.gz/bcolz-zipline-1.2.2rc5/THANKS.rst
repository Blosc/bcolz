bcolz has been created by Francesc Alted, so he must be responsible for
most of the bugs in the beast.

Valentin Haenel did an impressive work working as a maintainer and
release manager for long time.

Francesc Elies contributed many improvements to bcolz.

Gabi Davar contributed a much better setup.py.

Also, most of the Python 3 support is a back porting of the work that
Mark Wiebe did for the BLZ package.

Matthew Rocklin and Phillip Cloud contributed conda and binstar recipes.

Alistair Miles contributed the conda-forge recipe and other improvements.

Many other contributed bug fixes and new features.
