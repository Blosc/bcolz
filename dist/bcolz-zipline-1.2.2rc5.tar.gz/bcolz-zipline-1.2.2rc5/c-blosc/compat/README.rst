Compressed datafiles for testing backward/forward compatibility
===============================================================

The files here have been created with different versions of the C-Blosc library and are meant to test backward/forward compatibility among different versions of the library.
